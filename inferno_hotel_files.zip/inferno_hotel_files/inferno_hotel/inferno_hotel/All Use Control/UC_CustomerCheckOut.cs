﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace inferno_hotel.All_Use_Control
{
    public partial class UC_CustomerCheckOut : UserControl
    {
        Function fn = new Function();
        string query;
        public UC_CustomerCheckOut()
        {
            InitializeComponent();
        }

        private void UC_CustomerCheckOut_Load(object sender, EventArgs e)
        {
            query = "select customer.cid,customer.cname,customer.mobile,customer.nationaliy,customer.gender,customer.dob,customer.idproof,customer.addres,customer.checkin,rooms.roomNo,rooms.roomType,rooms.bed,rooms.price from customer inner join rooms on customer.roomid = rooms.roomid where chekout='NO'";

            DataSet ds = fn.GetData(query);
            gunaDataGridView1.DataSource = ds.Tables[0];

        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {
            query = "select customer.cid,customer.cname,customer.mobile,customer.nationaliy,customer.gender,customer.dob,customer.idproof,customer.addres,customer.checkin,rooms.roomNo,rooms.roomType,rooms.bed,rooms.price from customer inner join rooms on customer.roomid= rooms.roomid where cname like '" + txtName+"%'and chekout='NO' ";
            DataSet ds = fn.GetData(query);
            gunaDataGridView1.DataSource = ds.Tables[0];
        }

        int id;
        private void gunaDataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (gunaDataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
            {
                id = int.Parse(gunaDataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());
                txtCName.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
               txtRoomNo.Text= gunaDataGridView1.Rows[e.RowIndex].Cells[9].Value.ToString();
            }
        }

        private void btnCheckOut_Click(object sender, EventArgs e)
        {
            if (txtName.Text != "")
            {
                if (MessageBox.Show("Are you Sure?","Confirmation", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning)== DialogResult.OK)
                    {
                    query = "update customer set chekout='YES',checkout='"+txtCheckOutDate+"'where cid="+id+" update rooms set booked='NO' where roomNO= '"+txtRoomNo.Text+"'";
                    fn.setData(query,"check out successfully.");
                    UC_CustomerCheckOut_Load(this,null);
                    }
            }
            else
            {
                MessageBox.Show("No Customer selected","Message", MessageBoxButtons.OK,MessageBoxIcon.Information);

            }
        }
        public void clearAll()
        {
            txtName.Clear();
            txtCName.Clear();
            txtRoomNo.Clear();
            txtCheckOutDate.ResetText();
        }

        private void UC_CustomerCheckOut_Leave(object sender, EventArgs e)
        {
            clearAll();
        }
    }
}
