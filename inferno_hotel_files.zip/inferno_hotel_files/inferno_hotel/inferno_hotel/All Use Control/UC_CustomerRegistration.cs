﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace inferno_hotel.All_Use_Control
{
    public partial class UC_CustomerRegistration : UserControl
    {
        Function fn = new Function();
        string query;
      
        public UC_CustomerRegistration()
        {
            InitializeComponent();
        }

        public void setComboBox(string query , ComboBox combo)
        {
            SqlDataReader sdr = fn.getForCombo(query);
            while (sdr.Read())
            {
                for (int i = 0; i < sdr.FieldCount; i++)
                {
                    combo.Items.Add(sdr.GetString(i));
                }
            }
            sdr.Close();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void gunaDateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }
        private void txtRoomTypes_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtRoomNo.Items.Clear();
            txtPrice.Clear();
            query = "select roomNo from rooms where bed='" + txtBed.Text + "' and roomType='" + txtRoomTypes.Text + "' and booked= 'NO' ";
            setComboBox(query, txtRoomNo);
        }

        private void txtBed_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtRoomTypes.SelectedIndex = -1;
            txtRoomNo.Items.Clear();
            txtPrice.Clear();
        }
        int rid;

        private void txtRoomNo_SelectedIndexChanged(object sender, EventArgs e)
        {
            query = "select price,roomid from rooms where roomNo= '"+txtRoomNo.Text+"' ";
            DataSet ds = fn.GetData(query);
            txtPrice.Text = ds.Tables[0].Rows[0][0].ToString();
            rid = int.Parse(ds.Tables[0].Rows[0][1].ToString());
        }

        private void btnAlloteRoom_Click(object sender, EventArgs e)
        {
            if (txtName.Text != "" && txtMobileNo.Text != "" && txtNationality.Text != "" && txtGender.Text != "" && txtDateofBirth.Text != "" && txtIdProof.Text != "" && txtAddress.Text != "" && txtCheckIn.Text != "" && txtPrice.Text != "")
            {
                string name = txtName.Text;
                Int64 mobile = Int64.Parse(txtMobileNo.Text);
                string national = txtNationality.Text;
                string gender = txtGender.Text;
                string bob = txtDateofBirth.Text;
                string idproof = txtIdProof.Text;
                string address = txtAddress.Text;
                string checkin = txtCheckIn.Text;

                query = "insert into customer(cname,mobile,nationaliy,gender,dob,idproof,addres,checkin,roomid)values('" + name + "','" + mobile + "','" + national + "','" + gender + "','" + bob + "','" + idproof + "','" + address + "','" + checkin + "'," +rid+ ") update rooms set booked = 'YES' where roomNO = '" + txtRoomNo.Text + "'";
                fn.setData(query, "Room No" + txtRoomNo.Text + "Allocation Successful");
                clearAll();
            }
            else
            {
                MessageBox.Show("All Fielad are madetory.", "Information !!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        public void clearAll()
        {
            txtName.Clear();
            txtMobileNo.Clear();
            txtNationality.Clear();
            txtGender.SelectedIndex = -1;
            txtDateofBirth.ResetText();
            txtIdProof.Clear();
            txtAddress.Clear();
            txtCheckIn.ResetText();
            txtBed.SelectedIndex = -1;
            txtRoomTypes.SelectedIndex = -1;
            txtRoomNo.Items.Clear();
            txtPrice.Clear();
        }

        private void UC_CustomerRegistration_Leave(object sender, EventArgs e)
        {
            clearAll();
        }
    }
}
 