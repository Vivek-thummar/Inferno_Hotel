﻿
namespace inferno_hotel
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.gunaCirclePictureBox3 = new Guna.UI.WinForms.GunaCirclePictureBox();
            this.txtEnterUserEmail = new Guna.UI.WinForms.GunaTextBox();
            this.btnVerifyOTP = new Guna.UI.WinForms.GunaButton();
            this.btnSendOTP = new Guna.UI.WinForms.GunaButton();
            this.lblVerifyCode = new System.Windows.Forms.Label();
            this.txtVerifyCode = new Guna.UI.WinForms.GunaTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.gunaCirclePictureBox2 = new Guna.UI.WinForms.GunaCirclePictureBox();
            this.gunaCirclePictureBox1 = new Guna.UI.WinForms.GunaCirclePictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaCirclePictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaCirclePictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaCirclePictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.gunaCirclePictureBox3);
            this.panel1.Controls.Add(this.txtEnterUserEmail);
            this.panel1.Controls.Add(this.btnVerifyOTP);
            this.panel1.Controls.Add(this.btnSendOTP);
            this.panel1.Controls.Add(this.lblVerifyCode);
            this.panel1.Controls.Add(this.txtVerifyCode);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.gunaCirclePictureBox2);
            this.panel1.Controls.Add(this.gunaCirclePictureBox1);
            this.panel1.Location = new System.Drawing.Point(289, 144);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(656, 363);
            this.panel1.TabIndex = 0;
            // 
            // gunaCirclePictureBox3
            // 
            this.gunaCirclePictureBox3.BaseColor = System.Drawing.Color.White;
            this.gunaCirclePictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("gunaCirclePictureBox3.Image")));
            this.gunaCirclePictureBox3.Location = new System.Drawing.Point(3, 3);
            this.gunaCirclePictureBox3.Name = "gunaCirclePictureBox3";
            this.gunaCirclePictureBox3.Size = new System.Drawing.Size(44, 42);
            this.gunaCirclePictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaCirclePictureBox3.TabIndex = 65;
            this.gunaCirclePictureBox3.TabStop = false;
            this.gunaCirclePictureBox3.UseTransfarantBackground = false;
            this.gunaCirclePictureBox3.Click += new System.EventHandler(this.gunaCirclePictureBox3_Click);
            // 
            // txtEnterUserEmail
            // 
            this.txtEnterUserEmail.BackColor = System.Drawing.Color.Transparent;
            this.txtEnterUserEmail.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtEnterUserEmail.BorderColor = System.Drawing.Color.Silver;
            this.txtEnterUserEmail.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtEnterUserEmail.FocusedBaseColor = System.Drawing.Color.White;
            this.txtEnterUserEmail.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.txtEnterUserEmail.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.txtEnterUserEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEnterUserEmail.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtEnterUserEmail.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.txtEnterUserEmail.Location = new System.Drawing.Point(349, 98);
            this.txtEnterUserEmail.Name = "txtEnterUserEmail";
            this.txtEnterUserEmail.PasswordChar = '\0';
            this.txtEnterUserEmail.Radius = 5;
            this.txtEnterUserEmail.SelectedText = "";
            this.txtEnterUserEmail.Size = new System.Drawing.Size(242, 40);
            this.txtEnterUserEmail.TabIndex = 1;
            this.txtEnterUserEmail.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnVerifyOTP
            // 
            this.btnVerifyOTP.AnimationHoverSpeed = 0.07F;
            this.btnVerifyOTP.AnimationSpeed = 0.03F;
            this.btnVerifyOTP.BackColor = System.Drawing.Color.Transparent;
            this.btnVerifyOTP.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.btnVerifyOTP.BorderColor = System.Drawing.Color.Black;
            this.btnVerifyOTP.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnVerifyOTP.FocusedColor = System.Drawing.Color.Empty;
            this.btnVerifyOTP.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnVerifyOTP.ForeColor = System.Drawing.Color.White;
            this.btnVerifyOTP.Image = ((System.Drawing.Image)(resources.GetObject("btnVerifyOTP.Image")));
            this.btnVerifyOTP.ImageSize = new System.Drawing.Size(20, 20);
            this.btnVerifyOTP.Location = new System.Drawing.Point(474, 275);
            this.btnVerifyOTP.Name = "btnVerifyOTP";
            this.btnVerifyOTP.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.btnVerifyOTP.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btnVerifyOTP.OnHoverForeColor = System.Drawing.Color.White;
            this.btnVerifyOTP.OnHoverImage = null;
            this.btnVerifyOTP.OnPressedColor = System.Drawing.Color.Black;
            this.btnVerifyOTP.Radius = 20;
            this.btnVerifyOTP.Size = new System.Drawing.Size(117, 37);
            this.btnVerifyOTP.TabIndex = 4;
            this.btnVerifyOTP.Text = "Verify OTP";
            this.btnVerifyOTP.Visible = false;
            this.btnVerifyOTP.Click += new System.EventHandler(this.btnVerifyOTP_Click);
            // 
            // btnSendOTP
            // 
            this.btnSendOTP.AnimationHoverSpeed = 0.07F;
            this.btnSendOTP.AnimationSpeed = 0.03F;
            this.btnSendOTP.BackColor = System.Drawing.Color.Transparent;
            this.btnSendOTP.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.btnSendOTP.BorderColor = System.Drawing.Color.Black;
            this.btnSendOTP.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnSendOTP.FocusedColor = System.Drawing.Color.Empty;
            this.btnSendOTP.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnSendOTP.ForeColor = System.Drawing.Color.White;
            this.btnSendOTP.Image = ((System.Drawing.Image)(resources.GetObject("btnSendOTP.Image")));
            this.btnSendOTP.ImageSize = new System.Drawing.Size(20, 20);
            this.btnSendOTP.Location = new System.Drawing.Point(474, 144);
            this.btnSendOTP.Name = "btnSendOTP";
            this.btnSendOTP.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.btnSendOTP.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btnSendOTP.OnHoverForeColor = System.Drawing.Color.White;
            this.btnSendOTP.OnHoverImage = null;
            this.btnSendOTP.OnPressedColor = System.Drawing.Color.Black;
            this.btnSendOTP.Radius = 20;
            this.btnSendOTP.Size = new System.Drawing.Size(117, 37);
            this.btnSendOTP.TabIndex = 2;
            this.btnSendOTP.Text = "Send OTP";
            this.btnSendOTP.Click += new System.EventHandler(this.btnSendOTP_Click);
            // 
            // lblVerifyCode
            // 
            this.lblVerifyCode.AutoSize = true;
            this.lblVerifyCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVerifyCode.Location = new System.Drawing.Point(426, 206);
            this.lblVerifyCode.Name = "lblVerifyCode";
            this.lblVerifyCode.Size = new System.Drawing.Size(102, 20);
            this.lblVerifyCode.TabIndex = 64;
            this.lblVerifyCode.Text = "Verify Code";
            this.lblVerifyCode.Visible = false;
            // 
            // txtVerifyCode
            // 
            this.txtVerifyCode.BackColor = System.Drawing.Color.Transparent;
            this.txtVerifyCode.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtVerifyCode.BorderColor = System.Drawing.Color.Silver;
            this.txtVerifyCode.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtVerifyCode.FocusedBaseColor = System.Drawing.Color.White;
            this.txtVerifyCode.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.txtVerifyCode.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.txtVerifyCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVerifyCode.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtVerifyCode.Location = new System.Drawing.Point(349, 229);
            this.txtVerifyCode.Name = "txtVerifyCode";
            this.txtVerifyCode.PasswordChar = '\0';
            this.txtVerifyCode.Radius = 5;
            this.txtVerifyCode.SelectedText = "";
            this.txtVerifyCode.Size = new System.Drawing.Size(242, 40);
            this.txtVerifyCode.TabIndex = 3;
            this.txtVerifyCode.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtVerifyCode.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(392, 75);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(145, 20);
            this.label2.TabIndex = 44;
            this.label2.Text = "Enter User Email";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(414, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(123, 24);
            this.label1.TabIndex = 2;
            this.label1.Text = "User Loging";
            // 
            // gunaCirclePictureBox2
            // 
            this.gunaCirclePictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.gunaCirclePictureBox2.BaseColor = System.Drawing.Color.White;
            this.gunaCirclePictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("gunaCirclePictureBox2.Image")));
            this.gunaCirclePictureBox2.Location = new System.Drawing.Point(50, 61);
            this.gunaCirclePictureBox2.Name = "gunaCirclePictureBox2";
            this.gunaCirclePictureBox2.Size = new System.Drawing.Size(260, 235);
            this.gunaCirclePictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.gunaCirclePictureBox2.TabIndex = 1;
            this.gunaCirclePictureBox2.TabStop = false;
            this.gunaCirclePictureBox2.UseTransfarantBackground = true;
            // 
            // gunaCirclePictureBox1
            // 
            this.gunaCirclePictureBox1.BaseColor = System.Drawing.Color.White;
            this.gunaCirclePictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("gunaCirclePictureBox1.Image")));
            this.gunaCirclePictureBox1.Location = new System.Drawing.Point(50, 61);
            this.gunaCirclePictureBox1.Name = "gunaCirclePictureBox1";
            this.gunaCirclePictureBox1.Size = new System.Drawing.Size(260, 235);
            this.gunaCirclePictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.gunaCirclePictureBox1.TabIndex = 0;
            this.gunaCirclePictureBox1.TabStop = false;
            this.gunaCirclePictureBox1.UseTransfarantBackground = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(971, 519);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaCirclePictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaCirclePictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaCirclePictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private Guna.UI.WinForms.GunaCirclePictureBox gunaCirclePictureBox1;
        private Guna.UI.WinForms.GunaCirclePictureBox gunaCirclePictureBox2;
        private System.Windows.Forms.Label label1;
        private Guna.UI.WinForms.GunaButton btnVerifyOTP;
        private Guna.UI.WinForms.GunaButton btnSendOTP;
        private System.Windows.Forms.Label lblVerifyCode;
        private Guna.UI.WinForms.GunaTextBox txtVerifyCode;
        private System.Windows.Forms.Label label2;
        private Guna.UI.WinForms.GunaTextBox txtEnterUserEmail;
        private Guna.UI.WinForms.GunaCirclePictureBox gunaCirclePictureBox3;
    }
}

