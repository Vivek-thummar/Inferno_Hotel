﻿
namespace inferno_hotel.All_Use_Control
{
    partial class UC_CustomerRegistration
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtName = new Guna.UI.WinForms.GunaTextBox();
            this.txtMobileNo = new Guna.UI.WinForms.GunaTextBox();
            this.txtNationality = new Guna.UI.WinForms.GunaTextBox();
            this.txtGender = new Guna.UI.WinForms.GunaComboBox();
            this.txtDateofBirth = new Guna.UI.WinForms.GunaDateTimePicker();
            this.txtAddress = new Guna.UI.WinForms.GunaTextBox();
            this.txtIdProof = new Guna.UI.WinForms.GunaTextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtCheckIn = new Guna.UI.WinForms.GunaDateTimePicker();
            this.label9 = new System.Windows.Forms.Label();
            this.txtPrice = new Guna.UI.WinForms.GunaTextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.btnAlloteRoom = new Guna.UI.WinForms.GunaButton();
            this.txtBed = new Guna.UI.WinForms.GunaComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtRoomTypes = new Guna.UI.WinForms.GunaComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtRoomNo = new Guna.UI.WinForms.GunaComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.gunaElipse1 = new Guna.UI.WinForms.GunaElipse(this.components);
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(322, 36);
            this.label1.TabIndex = 0;
            this.label1.Text = "Customer Registration";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(26, 87);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 21);
            this.label2.TabIndex = 1;
            this.label2.Text = "Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(26, 172);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(91, 21);
            this.label3.TabIndex = 2;
            this.label3.Text = "Mobile No";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(26, 258);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(93, 21);
            this.label4.TabIndex = 3;
            this.label4.Text = "Nationality";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(26, 336);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(66, 21);
            this.label5.TabIndex = 4;
            this.label5.Text = "Gender";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(26, 420);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(108, 21);
            this.label6.TabIndex = 5;
            this.label6.Text = "Date of Birth";
            // 
            // txtName
            // 
            this.txtName.BaseColor = System.Drawing.Color.White;
            this.txtName.BorderColor = System.Drawing.Color.Silver;
            this.txtName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtName.FocusedBaseColor = System.Drawing.Color.White;
            this.txtName.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.txtName.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.txtName.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtName.Location = new System.Drawing.Point(30, 111);
            this.txtName.Name = "txtName";
            this.txtName.PasswordChar = '\0';
            this.txtName.SelectedText = "";
            this.txtName.Size = new System.Drawing.Size(352, 30);
            this.txtName.TabIndex = 6;
            // 
            // txtMobileNo
            // 
            this.txtMobileNo.BaseColor = System.Drawing.Color.White;
            this.txtMobileNo.BorderColor = System.Drawing.Color.Silver;
            this.txtMobileNo.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtMobileNo.FocusedBaseColor = System.Drawing.Color.White;
            this.txtMobileNo.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.txtMobileNo.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.txtMobileNo.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtMobileNo.Location = new System.Drawing.Point(30, 196);
            this.txtMobileNo.Name = "txtMobileNo";
            this.txtMobileNo.PasswordChar = '\0';
            this.txtMobileNo.SelectedText = "";
            this.txtMobileNo.Size = new System.Drawing.Size(352, 30);
            this.txtMobileNo.TabIndex = 7;
            // 
            // txtNationality
            // 
            this.txtNationality.BaseColor = System.Drawing.Color.White;
            this.txtNationality.BorderColor = System.Drawing.Color.Silver;
            this.txtNationality.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtNationality.FocusedBaseColor = System.Drawing.Color.White;
            this.txtNationality.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.txtNationality.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.txtNationality.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtNationality.Location = new System.Drawing.Point(30, 282);
            this.txtNationality.Name = "txtNationality";
            this.txtNationality.PasswordChar = '\0';
            this.txtNationality.SelectedText = "";
            this.txtNationality.Size = new System.Drawing.Size(352, 30);
            this.txtNationality.TabIndex = 8;
            // 
            // txtGender
            // 
            this.txtGender.BackColor = System.Drawing.Color.Transparent;
            this.txtGender.BaseColor = System.Drawing.Color.White;
            this.txtGender.BorderColor = System.Drawing.Color.Silver;
            this.txtGender.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.txtGender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtGender.FocusedColor = System.Drawing.Color.Empty;
            this.txtGender.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtGender.ForeColor = System.Drawing.Color.Black;
            this.txtGender.FormattingEnabled = true;
            this.txtGender.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Other"});
            this.txtGender.Location = new System.Drawing.Point(30, 360);
            this.txtGender.Name = "txtGender";
            this.txtGender.OnHoverItemBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.txtGender.OnHoverItemForeColor = System.Drawing.Color.White;
            this.txtGender.Size = new System.Drawing.Size(352, 26);
            this.txtGender.TabIndex = 9;
            // 
            // txtDateofBirth
            // 
            this.txtDateofBirth.BaseColor = System.Drawing.Color.White;
            this.txtDateofBirth.BorderColor = System.Drawing.Color.Silver;
            this.txtDateofBirth.CustomFormat = null;
            this.txtDateofBirth.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.txtDateofBirth.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.txtDateofBirth.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtDateofBirth.ForeColor = System.Drawing.Color.Black;
            this.txtDateofBirth.Location = new System.Drawing.Point(30, 444);
            this.txtDateofBirth.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.txtDateofBirth.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.txtDateofBirth.Name = "txtDateofBirth";
            this.txtDateofBirth.OnHoverBaseColor = System.Drawing.Color.White;
            this.txtDateofBirth.OnHoverBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.txtDateofBirth.OnHoverForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.txtDateofBirth.OnPressedColor = System.Drawing.Color.Black;
            this.txtDateofBirth.Size = new System.Drawing.Size(352, 30);
            this.txtDateofBirth.TabIndex = 10;
            this.txtDateofBirth.Text = "21 September 2023";
            this.txtDateofBirth.Value = new System.DateTime(2023, 9, 21, 18, 17, 42, 64);
            this.txtDateofBirth.ValueChanged += new System.EventHandler(this.gunaDateTimePicker1_ValueChanged);
            // 
            // txtAddress
            // 
            this.txtAddress.BaseColor = System.Drawing.Color.White;
            this.txtAddress.BorderColor = System.Drawing.Color.Silver;
            this.txtAddress.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtAddress.FocusedBaseColor = System.Drawing.Color.White;
            this.txtAddress.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.txtAddress.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.txtAddress.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtAddress.Location = new System.Drawing.Point(452, 196);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.PasswordChar = '\0';
            this.txtAddress.SelectedText = "";
            this.txtAddress.Size = new System.Drawing.Size(352, 30);
            this.txtAddress.TabIndex = 14;
            // 
            // txtIdProof
            // 
            this.txtIdProof.BaseColor = System.Drawing.Color.White;
            this.txtIdProof.BorderColor = System.Drawing.Color.Silver;
            this.txtIdProof.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtIdProof.FocusedBaseColor = System.Drawing.Color.White;
            this.txtIdProof.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.txtIdProof.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.txtIdProof.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtIdProof.Location = new System.Drawing.Point(452, 111);
            this.txtIdProof.Name = "txtIdProof";
            this.txtIdProof.PasswordChar = '\0';
            this.txtIdProof.SelectedText = "";
            this.txtIdProof.Size = new System.Drawing.Size(352, 30);
            this.txtIdProof.TabIndex = 13;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(448, 172);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(70, 21);
            this.label7.TabIndex = 12;
            this.label7.Text = "Address";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(448, 87);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(74, 21);
            this.label8.TabIndex = 11;
            this.label8.Text = "ID Proof";
            // 
            // txtCheckIn
            // 
            this.txtCheckIn.BaseColor = System.Drawing.Color.White;
            this.txtCheckIn.BorderColor = System.Drawing.Color.Silver;
            this.txtCheckIn.CustomFormat = null;
            this.txtCheckIn.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.txtCheckIn.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.txtCheckIn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtCheckIn.ForeColor = System.Drawing.Color.Black;
            this.txtCheckIn.Location = new System.Drawing.Point(452, 282);
            this.txtCheckIn.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.txtCheckIn.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.txtCheckIn.Name = "txtCheckIn";
            this.txtCheckIn.OnHoverBaseColor = System.Drawing.Color.White;
            this.txtCheckIn.OnHoverBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.txtCheckIn.OnHoverForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.txtCheckIn.OnPressedColor = System.Drawing.Color.Black;
            this.txtCheckIn.Size = new System.Drawing.Size(352, 30);
            this.txtCheckIn.TabIndex = 16;
            this.txtCheckIn.Text = "21 September 2023";
            this.txtCheckIn.Value = new System.DateTime(2023, 9, 21, 18, 17, 42, 64);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(448, 258);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(77, 21);
            this.label9.TabIndex = 15;
            this.label9.Text = "Check In";
            // 
            // txtPrice
            // 
            this.txtPrice.BaseColor = System.Drawing.Color.White;
            this.txtPrice.BorderColor = System.Drawing.Color.Silver;
            this.txtPrice.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtPrice.FocusedBaseColor = System.Drawing.Color.White;
            this.txtPrice.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.txtPrice.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.txtPrice.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtPrice.Location = new System.Drawing.Point(890, 360);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.PasswordChar = '\0';
            this.txtPrice.SelectedText = "";
            this.txtPrice.Size = new System.Drawing.Size(352, 30);
            this.txtPrice.TabIndex = 24;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(886, 336);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(47, 21);
            this.label13.TabIndex = 23;
            this.label13.Text = "Price";
            // 
            // btnAlloteRoom
            // 
            this.btnAlloteRoom.AnimationHoverSpeed = 0.07F;
            this.btnAlloteRoom.AnimationSpeed = 0.03F;
            this.btnAlloteRoom.BackColor = System.Drawing.Color.Transparent;
            this.btnAlloteRoom.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.btnAlloteRoom.BorderColor = System.Drawing.Color.Black;
            this.btnAlloteRoom.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnAlloteRoom.FocusedColor = System.Drawing.Color.Empty;
            this.btnAlloteRoom.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAlloteRoom.ForeColor = System.Drawing.Color.White;
            this.btnAlloteRoom.Image = null;
            this.btnAlloteRoom.ImageSize = new System.Drawing.Size(20, 20);
            this.btnAlloteRoom.Location = new System.Drawing.Point(1086, 432);
            this.btnAlloteRoom.Name = "btnAlloteRoom";
            this.btnAlloteRoom.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.btnAlloteRoom.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btnAlloteRoom.OnHoverForeColor = System.Drawing.Color.White;
            this.btnAlloteRoom.OnHoverImage = null;
            this.btnAlloteRoom.OnPressedColor = System.Drawing.Color.Black;
            this.btnAlloteRoom.Radius = 15;
            this.btnAlloteRoom.Size = new System.Drawing.Size(156, 42);
            this.btnAlloteRoom.TabIndex = 25;
            this.btnAlloteRoom.Text = "Allote Room";
            this.btnAlloteRoom.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnAlloteRoom.Click += new System.EventHandler(this.btnAlloteRoom_Click);
            // 
            // txtBed
            // 
            this.txtBed.BackColor = System.Drawing.Color.Transparent;
            this.txtBed.BaseColor = System.Drawing.Color.White;
            this.txtBed.BorderColor = System.Drawing.Color.Silver;
            this.txtBed.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.txtBed.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtBed.FocusedColor = System.Drawing.Color.Empty;
            this.txtBed.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtBed.ForeColor = System.Drawing.Color.Black;
            this.txtBed.FormattingEnabled = true;
            this.txtBed.Items.AddRange(new object[] {
            "Single",
            "Double",
            "Triple"});
            this.txtBed.Location = new System.Drawing.Point(890, 115);
            this.txtBed.Name = "txtBed";
            this.txtBed.OnHoverItemBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.txtBed.OnHoverItemForeColor = System.Drawing.Color.White;
            this.txtBed.Size = new System.Drawing.Size(352, 26);
            this.txtBed.TabIndex = 27;
            this.txtBed.SelectedIndexChanged += new System.EventHandler(this.txtBed_SelectedIndexChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(886, 91);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(39, 21);
            this.label10.TabIndex = 26;
            this.label10.Text = "Bed";
            // 
            // txtRoomTypes
            // 
            this.txtRoomTypes.BackColor = System.Drawing.Color.Transparent;
            this.txtRoomTypes.BaseColor = System.Drawing.Color.White;
            this.txtRoomTypes.BorderColor = System.Drawing.Color.Silver;
            this.txtRoomTypes.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.txtRoomTypes.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtRoomTypes.FocusedColor = System.Drawing.Color.Empty;
            this.txtRoomTypes.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtRoomTypes.ForeColor = System.Drawing.Color.Black;
            this.txtRoomTypes.FormattingEnabled = true;
            this.txtRoomTypes.Items.AddRange(new object[] {
            "AC",
            "Non-AC"});
            this.txtRoomTypes.Location = new System.Drawing.Point(890, 200);
            this.txtRoomTypes.Name = "txtRoomTypes";
            this.txtRoomTypes.OnHoverItemBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.txtRoomTypes.OnHoverItemForeColor = System.Drawing.Color.White;
            this.txtRoomTypes.Size = new System.Drawing.Size(352, 26);
            this.txtRoomTypes.TabIndex = 29;
            this.txtRoomTypes.SelectedIndexChanged += new System.EventHandler(this.txtRoomTypes_SelectedIndexChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(886, 176);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(103, 21);
            this.label11.TabIndex = 28;
            this.label11.Text = "Room Types";
            // 
            // txtRoomNo
            // 
            this.txtRoomNo.BackColor = System.Drawing.Color.Transparent;
            this.txtRoomNo.BaseColor = System.Drawing.Color.White;
            this.txtRoomNo.BorderColor = System.Drawing.Color.Silver;
            this.txtRoomNo.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.txtRoomNo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtRoomNo.FocusedColor = System.Drawing.Color.Empty;
            this.txtRoomNo.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtRoomNo.ForeColor = System.Drawing.Color.Black;
            this.txtRoomNo.FormattingEnabled = true;
            this.txtRoomNo.Location = new System.Drawing.Point(890, 272);
            this.txtRoomNo.Name = "txtRoomNo";
            this.txtRoomNo.OnHoverItemBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.txtRoomNo.OnHoverItemForeColor = System.Drawing.Color.White;
            this.txtRoomNo.Size = new System.Drawing.Size(352, 26);
            this.txtRoomNo.TabIndex = 31;
            this.txtRoomNo.SelectedIndexChanged += new System.EventHandler(this.txtRoomNo_SelectedIndexChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(886, 248);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(83, 21);
            this.label12.TabIndex = 30;
            this.label12.Text = "Room No";
            // 
            // gunaElipse1
            // 
            this.gunaElipse1.Radius = 30;
            this.gunaElipse1.TargetControl = this;
            // 
            // UC_CustomerRegistration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.Controls.Add(this.txtRoomNo);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.txtRoomTypes);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txtBed);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.btnAlloteRoom);
            this.Controls.Add(this.txtPrice);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.txtCheckIn);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtAddress);
            this.Controls.Add(this.txtIdProof);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtDateofBirth);
            this.Controls.Add(this.txtGender);
            this.Controls.Add(this.txtNationality);
            this.Controls.Add(this.txtMobileNo);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "UC_CustomerRegistration";
            this.Size = new System.Drawing.Size(1297, 505);
            this.Leave += new System.EventHandler(this.UC_CustomerRegistration_Leave);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private Guna.UI.WinForms.GunaTextBox txtName;
        private Guna.UI.WinForms.GunaTextBox txtMobileNo;
        private Guna.UI.WinForms.GunaTextBox txtNationality;
        private Guna.UI.WinForms.GunaComboBox txtGender;
        private Guna.UI.WinForms.GunaDateTimePicker txtDateofBirth;
        private Guna.UI.WinForms.GunaTextBox txtAddress;
        private Guna.UI.WinForms.GunaTextBox txtIdProof;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private Guna.UI.WinForms.GunaDateTimePicker txtCheckIn;
        private System.Windows.Forms.Label label9;
        private Guna.UI.WinForms.GunaTextBox txtPrice;
        private System.Windows.Forms.Label label13;
        private Guna.UI.WinForms.GunaButton btnAlloteRoom;
        private Guna.UI.WinForms.GunaComboBox txtBed;
        private System.Windows.Forms.Label label10;
        private Guna.UI.WinForms.GunaComboBox txtRoomTypes;
        private System.Windows.Forms.Label label11;
        private Guna.UI.WinForms.GunaComboBox txtRoomNo;
        private System.Windows.Forms.Label label12;
        private Guna.UI.WinForms.GunaElipse gunaElipse1;
    }
}
