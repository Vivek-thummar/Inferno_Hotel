﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace inferno_hotel
{
    class SqlHelper
    {
       /* public string connstring;
        public SqlConnection con;
        public SqlCommand cmd;

        public SqlHelper() { }

        public SqlHelper(string sp)
        {
            connstring = ConfigurationManager.AppSettings["constr"];
            con = new SqlConnection(connstring);
            cmd = new SqlCommand(sp, con);
            cmd.CommandType = CommandType.StoredProcedure;
        }
       */

    }
}
