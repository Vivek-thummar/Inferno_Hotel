﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace inferno_hotel
{
    
    public partial class Form1 : Form
    {
        Function fn = new Function();
        string query;

        String randomCode;
        public static string to;

        SqlConnection conCnnection = new SqlConnection(ConfigurationManager.ConnectionStrings["ConString"].ConnectionString);

        public Form1()
        {
            InitializeComponent();
        }

        private void btnSendOTP_Click(object sender, EventArgs e)
        {
            query = "select emailid from employee where emailid ='" + txtEnterUserEmail.Text + "' ";
            DataSet ds = fn.GetData(query);

            if (ds.Tables[0].Rows.Count != 0)
            {
                    string from, pass, messageBody;
                    Random rand = new Random();
                    randomCode = (rand.Next(9999)).ToString();
                    MailMessage message = new MailMessage();
                    to = (txtEnterUserEmail.Text).ToString();
                    from = "vivekthummar07@gmail.com";
                    pass = "cilqbgmpkyankxhl";
                    messageBody = "Your reset code  is " + randomCode;
                    message.To.Add(to);
                    message.From = new MailAddress(from);
                    message.Body = messageBody;
                    message.Subject = "password  Reseting Code";
                    SmtpClient smtp = new SmtpClient("smtp.gmail.com");
                    smtp.EnableSsl = true;
                    smtp.Port = 587;
                    smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
                    smtp.Credentials = new NetworkCredential(from, pass);

                try
                {
                    smtp.Send(message);
                    MessageBox.Show("Code send Successfully");
                    lblVerifyCode.Visible = true;
                    txtVerifyCode.Visible = true;
                    btnVerifyOTP.Visible = true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);

                }
            }
            else
            {
                MessageBox.Show("Email Id has not registered...!");
            }

        }
        private void btnVerifyOTP_Click(object sender, EventArgs e)
        {
            
                if (randomCode == (txtVerifyCode.Text).ToString())
                {
                    to = txtEnterUserEmail.Text;
                    Dashboard dr = new Dashboard();
                    this.Hide();
                    dr.Show();
                }
                else
                {
                    MessageBox.Show("Wroung Code");

                }

            
                
        }

        private void gunaCirclePictureBox3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
